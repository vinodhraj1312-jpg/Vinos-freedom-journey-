# Vino Life & Money Manager — Starter V1

## Included
- Daily planner with a 5:00 AM–10:30 PM editable template
- Habit checklist, daily completion score and simple streak counter
- Income and expense transaction recording
- Amma support and salary planning targets
- Daily journal
- Local JSON backup and restore
- Responsive dark interface

## Run locally
Open `index.html` in a modern browser. For installable PWA/offline caching, serve this folder over HTTPS or localhost (service workers do not run from ordinary `file://` URLs).

## iPhone
Host the folder on an HTTPS static host, open its URL in Safari, tap Share → Add to Home Screen.

## Android
Open the HTTPS URL in Chrome and use Install app / Add to Home screen.

## Privacy and limitations
Records are stored in browser localStorage on this device/browser profile. They are not encrypted at rest and do not sync to another device. Export JSON backups regularly. Do not use this starter for highly sensitive credentials or as a replacement for bank records.

This is a functional starter build, not a finished native iOS/Android app. Cloud backup, native biometric authentication, push notifications, advanced financial/debt modules, and native app-store packaging are not included yet.
